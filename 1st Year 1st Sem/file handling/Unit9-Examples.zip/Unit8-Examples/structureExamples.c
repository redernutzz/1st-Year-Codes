#include<stdio.h>
#include<conio.h>
//Structures are placed on global area outside the functions.

//Note: If the structure has tag name, you can create another structure
//		variable anywhere in the program.
struct personal_info{
	char id[10];
	char name[30];
	char course[10];
	int year;

}stud_info;

void Example1Basic();
void Example2Basic();
void Example3ArrStruct();

//functions below
int main(){
	//Example1Basic();
	//Example2Basic();
	Example3ArrStruct();
	return 0;
}

//Example 1 Basic structures
void Example1Basic(){
	printf("============Student============\n");
	//How to store data into structure
	printf("Enter your id#:");
	gets(stud_info.id);
	printf("Enter your name:");
	gets(stud_info.name);
	printf("Enter your course name:");
	gets(stud_info.course);
	printf("Enter your course year:");
	scanf("%d",&stud_info.year);

	//How to access data from structure
	printf("\nSUMMARY\n");
	printf("ID#:\t%s\n", stud_info.id);
	printf("NAME:\t%s\n", stud_info.name);
	printf("COURSE:\t%s\n", stud_info.course);
	printf("YEAR:\t%d\n", stud_info.year);

	return;
}


//Example 2 Creating structure variable
void Example2Basic(){
	struct personal_info employee;
	printf("============Employee============\n");
	printf("Enter your id#:");
	gets(employee.id);
	printf("Enter your name:");
	gets(employee.name);
	printf("Enter your # of years in service:");
	scanf("%d",&employee.year);

	printf("\nSUMMARY\n");
	printf("ID#:\t\t%s\n", employee.id);
	printf("NAME:\t\t%s\n", employee.name);
	printf("Service Years:\t%d\n", employee.year);

	return;
}


//Example 3 Creating array structure variable
#define MAX 5
void Example3ArrStruct(){
	struct personal_info stud_log[MAX];
	int count;
	char choice;

	for(count = 0; count < MAX; count++){
		printf("============Student Log #%d============\n", count+1);
		printf("Enter your id#:");
		gets(stud_log[count].id);
		printf("Enter your name:");
		gets(stud_log[count].name);
		printf("Enter your course name:");
		gets(stud_log[count].course);
		printf("Enter your course year:");
		scanf("%d",&stud_log[count].year);

		fflush(stdin);			//clears the input values of array of structures
		           				//in the input stream
		//fflush(stdout);		//clears the output values of array of structures
		           				//in the output stream
	}

    do{
        printf("\nStudent to Display\n");
        scanf("%d", &count);
        printf("ID#:\t%s\n", stud_log[count-1].id);
        printf("NAME:\t%s\n", stud_log[count-1].name);
        printf("Course:\t%s\n", stud_log[count-1].course);
        printf("Year:\t%d\n", stud_log[count-1].year);
        printf("\nPress any key to continue. Enter 0 to quit.");
        choice=getch();
    }while(choice!='0');

	return;
}
