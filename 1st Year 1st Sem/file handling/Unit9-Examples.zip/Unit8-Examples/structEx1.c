#include<stdio.h>
#include<string.h>

// Global Variables
// Create struct student with s1 variable
struct student {
    char id[10];
    char name[30];
    char course[10];
    int year;
}s1;

// Main Function
int main() {

    // Assign values to s1 variables
    strcpy(s1.name, "Juan dela Cruz");
    strcpy(s1.id, "123456");
    strcpy(s1.course, "BSCpE");
    s1.year = 1;

    // Print struct variables
    printf("Name:\t%s\n", s1.name);
    printf("ID Num:\t%s\n", s1.id);
    printf("Course:\t%s\n", s1.course);
    printf("Year:\t%d\n", s1.year);

    return 0;
}

