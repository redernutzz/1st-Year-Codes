#include <stdio.h>

int main(){
	FILE *fp;
	char text[80];

 	//This file creates new text file if non-existent then open
 	//otherwise if it exits, it just opens the file
        //fp = fopen("C:\\Users\\APMondigo\\Desktop\\abc.txt", "w");
 	fp = fopen("test.txt", "w");

 	printf("\nENTER TEXT BELOW\n");

 	//reads the input from the command terminal
        //scanf("%s", &text);
    fscanf(stdin, "%s", &text);

 	//displays the contents of variable "text"
 	fprintf(fp, text);
 	printf("\nThe text is copied to the file\n");

 	//closes the file
 	fclose(fp);

    return 0;
}
