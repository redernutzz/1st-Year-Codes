/*
 ============================================================================
 FILE        : structArray.c
 AUTHOR      : Elline L. Fabian
 DESCRIPTION : Program that demonstrates the use of structure array.
 COPYRIGHT   : 11 September 2012
 REVISION HISTORY
 Date: 			By: 		            Description:
 05 Dec 2021    Antoniette M. Canete    Minor modifications and comments
 ============================================================================
 */
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
#include<windows.h>

//Global variables
COORD coord ={0,0}; //sets coordinates to 0,0

//Function Prototypes
void gotoxy (int x, int y);
void menu();
int add(int i);
void view(int i);

//Definitions and Constants
#define MAX 10

//Global Variables
struct info{
	char id[6];
	char name[31];
};
struct info x[MAX];

/*
============================================================================
 FUNCTION    : mainbb
 DESCRIPTION : Execute the main module
 ARGUMENTS   : void
 RETURNS     : int - returns exit code
 ============================================================================
 */
int main()
{
	int i=0;
	char k;

	for(;;)
	{
        //Displays menu and ask for char input; loops if invalid input
		do{
			system("cls");
			//Calls menu() function
			menu();
			k=getch();
		}while(k!='a'&& k!='b'&& k!='q');

        //Check inputs
		if(k=='a')
		{   //Calls add() function and passing i as parameter
			i=add(i);
		}
		else if(k=='b')
		{   //Calls view() function and passing i as parameter
			view(i);
		}
		else
		{   //Exits code with exit code 0 (program successful)
			exit(0);
		}
	}
	return 0;
}

/*
============================================================================
 FUNCTION    : menu
 DESCRIPTION : Display main menu options
 ARGUMENTS   : void
 RETURNS     : void
 ============================================================================
*/
void menu()
{
	printf("MAIN MENU");
	printf("\n[a] A P P E N D");;
	printf("\n[b] B R O W S E");
	printf("\n[q] Q U I T ");
}

/*
============================================================================
 FUNCTION    : add
 DESCRIPTION : Append student to the structure array
 ARGUMENTS   : int i - index element / student counter
 RETURNS     : int - current count
 ============================================================================
*/
int add(int i)
{
	system("cls");
	printf("ID# : ");
	gets(x[i].id);
	printf("NAME: ");
	gets(x[i].name);
	i++;
	return i;
}

/*
============================================================================
 FUNCTION    : view
 DESCRIPTION : Display all entries in a tabular form
 ARGUMENTS   : int i - current count of students / elements in the
 			   structure array
 RETURNS     : void
 ============================================================================
*/
void view(int i)
{
	int a,b;
	system("cls");
	//printf("\n\n");
	gotoxy(10,3);
	printf("ID#");
	gotoxy(30,3);
	printf("NAME");
	b=5;
	for(a=0;a<=i;a++)
	{
		gotoxy(10,b);
		printf("%s",x[a].id);
		gotoxy(30,b);
		printf("%s",x[a].name);
		b++;
	}
	getch();
}

/*
============================================================================
 FUNCTION    : gotoxy
 DESCRIPTION : Position the cursor at indicated x and y coordinates
 ARGUMENTS   : int x - x-axis location of the cursor (column)
 			   int y - y-axis location of the cursor (row)
 RETURNS     : void
 ============================================================================
*/
void gotoxy (int x, int y)
{
	coord.X = x; coord.Y = y; //X and Y coordinates
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
